#!/bin/sh

curl https://android.googlesource.com/kernel/configs/+archive/master/android-4.9.tar.gz | tar xzv

